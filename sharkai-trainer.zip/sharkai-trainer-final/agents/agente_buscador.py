"""
AGENTE 1 - BUSCADOR
Busca y descarga documentación sobre especies de pesca en Galicia
desde fuentes abiertas en internet.
"""

import requests
from bs4 import BeautifulSoup
import json
import os
import time
import hashlib
from datetime import datetime

# Cabeceras para simular un navegador real
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
}

# Fuentes de información sobre pesca en Galicia/España
FUENTES = [
    {
        "nombre": "Wikipedia - Lubina europea",
        "url": "https://es.wikipedia.org/wiki/Dicentrarchus_labrax",
        "especie": "lubina"
    },
    {
        "nombre": "Wikipedia - Calamar común",
        "url": "https://es.wikipedia.org/wiki/Loligo_vulgaris",
        "especie": "calamar"
    },
    {
        "nombre": "Wikipedia - Dorada",
        "url": "https://es.wikipedia.org/wiki/Sparus_aurata",
        "especie": "dorada"
    },
    {
        "nombre": "Wikipedia - Rodaballo",
        "url": "https://es.wikipedia.org/wiki/Scophthalmus_maximus",
        "especie": "rodaballo"
    },
    {
        "nombre": "Wikipedia - Rape",
        "url": "https://es.wikipedia.org/wiki/Lophius_piscatorius",
        "especie": "rape"
    },
    {
        "nombre": "Wikipedia - Pulpo común",
        "url": "https://es.wikipedia.org/wiki/Octopus_vulgaris",
        "especie": "pulpo"
    },
    {
        "nombre": "Wikipedia - Besugo",
        "url": "https://es.wikipedia.org/wiki/Pagellus_bogaraveo",
        "especie": "besugo"
    },
    {
        "nombre": "Wikipedia - Mero",
        "url": "https://es.wikipedia.org/wiki/Epinephelus_marginatus",
        "especie": "mero"
    },
    {
        "nombre": "Wikipedia - Merluza europea",
        "url": "https://es.wikipedia.org/wiki/Merluccius_merluccius",
        "especie": "merluza"
    },
    {
        "nombre": "Wikipedia - Sargo",
        "url": "https://es.wikipedia.org/wiki/Diplodus_sargus",
        "especie": "sargo"
    },
]


def descargar_pagina(url: str) -> str | None:
    """Descarga el contenido HTML de una URL."""
    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        resp.raise_for_status()
        return resp.text
    except Exception as e:
        print(f"  [ERROR] No se pudo descargar {url}: {e}")
        return None


def extraer_texto_wikipedia(html: str) -> str:
    """Extrae el texto principal de una página de Wikipedia."""
    soup = BeautifulSoup(html, "lxml")

    # Eliminar elementos que no aportan contenido útil
    for tag in soup.find_all(["table", "style", "script", "sup", "span.reference"]):
        tag.decompose()

    # Buscar el contenido principal
    contenido = soup.find("div", {"id": "mw-content-text"})
    if not contenido:
        return ""

    parrafos = []
    for p in contenido.find_all("p"):
        texto = p.get_text(separator=" ", strip=True)
        if len(texto) > 60:  # Ignorar párrafos muy cortos
            parrafos.append(texto)

    return "\n\n".join(parrafos[:30])  # Máximo 30 párrafos por página


def generar_id(url: str) -> str:
    """Genera un ID único para cada documento."""
    return hashlib.md5(url.encode()).hexdigest()[:10]


def guardar_documento(especie: str, fuente: str, url: str, texto: str, carpeta: str):
    """Guarda el documento procesado en JSON."""
    doc = {
        "id": generar_id(url),
        "especie": especie,
        "fuente": fuente,
        "url": url,
        "fecha_descarga": datetime.now().isoformat(),
        "caracteres": len(texto),
        "contenido": texto
    }

    nombre_archivo = f"{especie}_{generar_id(url)}.json"
    ruta = os.path.join(carpeta, nombre_archivo)

    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)

    return ruta


def ejecutar(carpeta_docs: str = "data/docs") -> list[dict]:
    """Ejecuta el agente buscador y devuelve resumen de resultados."""
    os.makedirs(carpeta_docs, exist_ok=True)

    print("\n" + "="*60)
    print("  🦈 AGENTE BUSCADOR - SharkAI Trainer")
    print("="*60)
    print(f"  Buscando documentación de {len(FUENTES)} especies...\n")

    resultados = []

    for fuente in FUENTES:
        print(f"  📥 Descargando: {fuente['nombre']}")
        html = descargar_pagina(fuente["url"])

        if html:
            texto = extraer_texto_wikipedia(html)

            if len(texto) > 200:
                ruta = guardar_documento(
                    especie=fuente["especie"],
                    fuente=fuente["nombre"],
                    url=fuente["url"],
                    texto=texto,
                    carpeta=carpeta_docs
                )
                resultados.append({
                    "especie": fuente["especie"],
                    "fuente": fuente["nombre"],
                    "ruta": ruta,
                    "caracteres": len(texto),
                    "ok": True
                })
                print(f"     ✅ {len(texto):,} caracteres extraídos → {os.path.basename(ruta)}")
            else:
                print(f"     ⚠️  Contenido insuficiente, ignorando.")
                resultados.append({"especie": fuente["especie"], "ok": False})
        else:
            resultados.append({"especie": fuente["especie"], "ok": False})

        time.sleep(1)  # Respetar los servidores

    exitosos = sum(1 for r in resultados if r.get("ok"))
    print(f"\n  📊 Resultado: {exitosos}/{len(FUENTES)} documentos descargados correctamente.")

    return resultados


if __name__ == "__main__":
    ejecutar()
